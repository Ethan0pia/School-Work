/*********************************************************************
** Program name:Determinant Calculator
** Author: Ethan Dunham
** Date: 1/15/17
** Description: Header file for the determinant function.
*********************************************************************/

int determinant(int*, int);