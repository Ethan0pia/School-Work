package com.example.ethanDunham.androidui;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class RelativeViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_relative);

    }
}
